#include "util.hpp"

void FloodFill(int x, int y){
    if( screen[x][y] == BG ){
        screen[x][y] = INSIDE;
        
        if(x+1 < WIDTH) FloodFill(x+1, y);
        if(y+1 < HEIGHT) FloodFill(x, y+1);
        
        if(x > 0) FloodFill(x-1, y);
        if(y > 0) FloodFill(x, y-1);
    }
}


int main(int argc, char** argv){
    initPolygon();
    FloodFill(xc, yc);

    // GLute init and create window
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE);
    glutInitWindowSize(WIDTH,HEIGHT);
    glutInitWindowPosition(600,100);
    glutCreateWindow("Flood Fill");
    myInit();

    // Register display callback
    glutDisplayFunc(drawObject);

    glutMainLoop();
}

